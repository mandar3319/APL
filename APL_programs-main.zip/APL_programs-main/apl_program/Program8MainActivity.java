package com.example.apl_program;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class Program8MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_program8_main);
    }
}
